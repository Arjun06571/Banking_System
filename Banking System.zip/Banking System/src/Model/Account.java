package Model;

import java.util.Date;

public class Account
{
    private int accountNo;
    private int customerId;
    private String accountType;
    private double balance;
    private Date createdDate;
    private String status;

    // Constructors
    public Account() {}

    public Account(int customerId, String accountType, double balance)
    {
        this.customerId = customerId;
        this.accountType = accountType;
        this.balance = balance;
    }

    // Getters and Setters
    public int getAccountNo() { return accountNo; }
    public void setAccountNo(int accountNo) { this.accountNo = accountNo; }

    public int getCustomerId() { return customerId; }
    public void setCustomerId(int customerId) { this.customerId = customerId; }

    public String getAccountType() { return accountType; }
    public void setAccountType(String accountType) { this.accountType = accountType; }

    public double getBalance() { return balance; }
    public void setBalance(double balance) { this.balance = balance; }

    public Date getCreatedDate() { return createdDate; }
    public void setCreatedDate(Date createdDate) { this.createdDate = createdDate; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    @Override
    public String toString() {
        return String.format("Account No: %d, Type: %s, Balance: $%.2f, Status: %s",
                accountNo, accountType, balance, status);
    }
}