package Service;

import DAO.CustomerDAO;
import DAO.impl.CustomerDAOimpl;
import Model.Customer;
import java.util.List;

public class CustomerService
{
    private CustomerDAO customerDAO;

    public CustomerService()
    {
        this.customerDAO = new CustomerDAOimpl();
    }

    public boolean registerCustomer(String name, String email, String phone, String address)
    {
        // Validate input
        if (name == null || name.trim().isEmpty())
        {
            System.out.println("Error: Name cannot be empty!");
            return false;
        }

        if (email == null || !email.contains("@"))
        {
            System.out.println("Error: Invalid email format!");
            return false;
        }

        // Check if email already exists
        if (customerDAO.getCustomerByEmail(email) != null)
        {
            System.out.println("Error: Email already registered!");
            return false;
        }

        Customer customer = new Customer(name, email, phone, address);
        boolean success = customerDAO.addcustomer(customer);

        if (success)
        {
            System.out.println("Customer registered successfully!");
        } else
        {
            System.out.println("Failed to register customer!");
        }

        return success;
    }

    public Customer getCustomer(int customerId)

    {
        Customer customer = customerDAO.getCustomerById(customerId);
        if (customer == null)
        {
            System.out.println("Customer not found with ID: " + customerId);
        }
        return customer;
    }

    public Customer getCustomerByEmail(String email)
    {
        return customerDAO.getCustomerByEmail(email);
    }

    public List<Customer> getAllCustomers()
    {
        return customerDAO.getAllCustomers();
    }

    public boolean updateCustomer(int customerId, String name, String phone, String address)
    {
        Customer customer = customerDAO.getCustomerById(customerId);
        if (customer == null)
        {
            System.out.println("Customer not found!");
            return false;
        }

        customer.setName(name);
        customer.setPhone(phone);
        customer.setAddress(address);

        boolean success = customerDAO.updateCustomer(customer);
        if (success)
        {
            System.out.println("Customer updated successfully!");
        } else
        {
            System.out.println("Failed to update customer!");
        }

        return success;
    }

    public boolean deleteCustomer(int customerId)
    {
        // Check if customer exists
        if (!customerDAO.customerExists(customerId))
        {
            System.out.println("Customer not found!");
            return false;
        }

        boolean success = customerDAO.deleteCustomer(customerId);
        if (success)
        {
            System.out.println("Customer deleted successfully!");
        }
        else
        {
            System.out.println("Failed to delete customer!");
        }

        return success;
    }
}