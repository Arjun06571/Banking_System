package Service;

import DAO.AccountDAO;
import DAO.TransactionDAO;
import DAO.impl.AccountDAOimpl;
import DAO.impl.TransactionDAOImpl;
import Model.Account;
import Service.CustomerService;
import model.Transaction;
import java.util.List;

public class AccountService
{
    private AccountDAO accountDAO;
    private TransactionDAO transactionDAO;
    private CustomerService customerService;

    public AccountService()
    {
        this.accountDAO = new AccountDAOimpl();
        this.transactionDAO = new TransactionDAOImpl();
        this.customerService = new CustomerService() {
        };
    }

    public boolean createAccount(int customerId, String accountType, double initialDeposit) {
        // Validate customer exists
        if (customerService.getCustomer(customerId) == null) {
            System.out.println("Error: Customer does not exist!");
            return false;
        }

        // Validate account type
        if (!accountType.equalsIgnoreCase("SAVINGS") && !accountType.equalsIgnoreCase("CURRENT")) {
            System.out.println("Error: Account type must be SAVINGS or CURRENT!");
            return false;
        }

        // Validate initial deposit
        if (initialDeposit < 0) {
            System.out.println("Error: Initial deposit cannot be negative!");
            return false;
        }

        if (accountType.equalsIgnoreCase("SAVINGS") && initialDeposit < 100) {
            System.out.println("Error: Savings account requires minimum $100 deposit!");
            return false;
        }

        Account account = new Account(customerId, accountType.toUpperCase(), initialDeposit);
        boolean success = accountDAO.createAccount(account);

        if (success && initialDeposit > 0)
        {
            // Record initial deposit transaction
            Transaction transaction = new Transaction(
                    getLatestAccountNumber(),
                    "DEPOSIT",
                    initialDeposit,
                    "Initial deposit"
            );
            transactionDAO.addTransaction(transaction);
            System.out.println("Account created successfully with initial deposit!");
        } else if (success)
        {
            System.out.println("Account created successfully!");
        } else {
            System.out.println("Failed to create account!");
        }

        return success;
    }

    private int getLatestAccountNumber()
    {
        List<Account> accounts = accountDAO.getAllAccounts();
        if (accounts.isEmpty())
        {
            return 1; // First account
        }
        return accounts.get(accounts.size() - 1).getAccountNo();
    }

    public Account getAccount(int accountNo)
    {
        Account account = accountDAO.getAccountByNumber(accountNo);
        if (account == null)
        {
            System.out.println("Account not found!");
        }
        return account;
    }

    public List<Account> getCustomerAccounts(int customerId)
    {
        return accountDAO.getAccountsByCustomerId(customerId);
    }

    public double getBalance(int accountNo)
    {
        if (!accountDAO.accountExists(accountNo))
        {
            System.out.println("Account not found!");
            return -1;
        }

        double balance = accountDAO.getAccountBalance(accountNo);
        System.out.println("Account Balance: $" + balance);
        return balance;
    }

    public boolean deposit(int accountNo, double amount)
    {
        if (!validateAccount(accountNo)) return false;

        if (amount <= 0)
        {
            System.out.println("Error: Deposit amount must be positive!");
            return false;
        }

        double currentBalance = accountDAO.getAccountBalance(accountNo);
        double newBalance = currentBalance + amount;

        boolean success = accountDAO.updateAccountBalance(accountNo, newBalance);

        if (success)
        {
            // Record transaction
            Transaction transaction = new Transaction(accountNo, "DEPOSIT", amount, "Cash deposit");
            transactionDAO.addTransaction(transaction);
            System.out.println("Deposit successful! New balance: $" + newBalance);
        } else
        {
            System.out.println("Deposit failed!");
        }

        return success;
    }

    public boolean withdraw(int accountNo, double amount)
    {
        if (!validateAccount(accountNo)) return false;

        if (amount <= 0)
        {
            System.out.println("Error: Withdrawal amount must be positive!");
            return false;
        }

        double currentBalance = accountDAO.getAccountBalance(accountNo);

        if (amount > currentBalance)
        {
            System.out.println("Error: Insufficient funds! Available balance: $" + currentBalance);
            return false;
        }

        double newBalance = currentBalance - amount;
        boolean success = accountDAO.updateAccountBalance(accountNo, newBalance);

        if (success)
        {
            // Record transaction
            Transaction transaction = new Transaction(accountNo, "WITHDRAWAL", amount, "Cash withdrawal");
            transactionDAO.addTransaction(transaction);
            System.out.println("Withdrawal successful! New balance: $" + newBalance);
        } else {
            System.out.println("Withdrawal failed!");
        }

        return success;
    }

    public boolean transfer(int fromAccountNo, int toAccountNo, double amount)
    {
        if (!validateAccount(fromAccountNo) || !validateAccount(toAccountNo)) return false;

        if (fromAccountNo == toAccountNo)
        {
            System.out.println("Error: Cannot transfer to the same account!");
            return false;
        }

        if (amount <= 0)
        {
            System.out.println("Error: Transfer amount must be positive!");
            return false;
        }

        // Withdraw from source account
        if (!withdraw(fromAccountNo, amount))
        {
            return false;
        }

        // Deposit to target account
        if (!deposit(toAccountNo, amount))
        {
            // Rollback withdrawal if deposit fails
            deposit(fromAccountNo, amount);
            System.out.println("Transfer failed! Transaction rolled back.");
            return false;
        }

        // Record transfer transaction for both accounts
        Transaction transferOut = new Transaction(fromAccountNo, "TRANSFER_OUT", amount,
                "Transfer to account " + toAccountNo);
        Transaction transferIn = new Transaction(toAccountNo, "TRANSFER_IN", amount,
                "Transfer from account " + fromAccountNo);

        transactionDAO.addTransaction(transferOut);
        transactionDAO.addTransaction(transferIn);

        System.out.println("Transfer successful! $" + amount + " transferred from account " +
                fromAccountNo + " to account " + toAccountNo);
        return true;
    }

    public boolean closeAccount(int accountNo)
    {
        if (!validateAccount(accountNo)) return false;

        double balance = accountDAO.getAccountBalance(accountNo);
        if (balance > 0)
        {
            System.out.println("Error: Cannot close account with positive balance. Please withdraw funds first.");
            return false;
        }

        boolean success = accountDAO.closeAccount(accountNo);
        if (success)
        {
            System.out.println("Account closed successfully!");
        } else {
            System.out.println("Failed to close account!");
        }

        return success;
    }

    private boolean validateAccount(int accountNo)
    {
        if (!accountDAO.accountExists(accountNo))
        {
            System.out.println("Error: Account does not exist!");
            return false;
        }

        if (!accountDAO.isAccountActive(accountNo))
        {
            System.out.println("Error: Account is not active!");
            return false;
        }

        return true;
    }

    public List<Transaction> getTransactionHistory(int accountNo)
    {
        if (!validateAccount(accountNo)) return null;

        return transactionDAO.getTransactionsByAccount(accountNo);
    }

    public List<Account> getAllAccounts()
    {
        return accountDAO.getAllAccounts();
    }
}