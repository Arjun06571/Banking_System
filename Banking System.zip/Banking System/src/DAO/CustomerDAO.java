package DAO;

import Model.Customer;
import java.util.List;

public interface CustomerDAO
{

    // Create
    boolean addcustomer(Customer customer );

    // read
    Customer getCustomerById(int customerId);
    Customer getCustomerByEmail(String email);
    List<Customer> getAllCustomers();

    // Update
    boolean updateCustomer(Customer customer);

    // Delete
    boolean deleteCustomer(int customerId);

    // Validation
    boolean customerExists(int customerId);
}
