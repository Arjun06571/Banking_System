package DAO.impl;

import DAO.TransactionDAO;
import model.Transaction;
import util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TransactionDAOImpl implements TransactionDAO
{

    @Override
    public boolean addTransaction(Transaction transaction)
    {
        String sql = "INSERT INTO transactions (account_no, transaction_type, amount, description) VALUES (?, ?, ?, ?)";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql))
        {

            ps.setInt(1, transaction.getAccountNo());
            ps.setString(2, transaction.getTransactionType());
            ps.setDouble(3, transaction.getAmount());
            ps.setString(4, transaction.getDescription());

            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e)
        {
            System.err.println("Error adding transaction: " + e.getMessage());
            return false;
        }
    }

    @Override
    public Transaction getTransactionById(int transactionId)
    {
        String sql = "SELECT * FROM transactions WHERE transaction_id = ?";
        Transaction transaction = null;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql))
        {

            ps.setInt(1, transactionId);
            ResultSet rs = ps.executeQuery();

            if (rs.next())
            {
                transaction = new Transaction();
                transaction.setTransactionId(rs.getInt("transaction_id"));
                transaction.setAccountNo(rs.getInt("account_no"));
                transaction.setTransactionType(rs.getString("transaction_type"));
                transaction.setAmount(rs.getDouble("amount"));
                transaction.setTransactionDate(rs.getTimestamp("transaction_date"));
                transaction.setDescription(rs.getString("description"));
            }

        } catch (SQLException e)
        {
            System.err.println("Error getting transaction: " + e.getMessage());
        }

        return transaction;
    }

    @Override
    public List<Transaction> getTransactionsByAccount(int accountNo)
    {
        List<Transaction> transactions = new ArrayList<>();
        String sql = "SELECT * FROM transactions WHERE account_no = ? ORDER BY transaction_date DESC";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql))
        {

            ps.setInt(1, accountNo);
            ResultSet rs = ps.executeQuery();

            while (rs.next())
            {
                Transaction transaction = new Transaction();
                transaction.setTransactionId(rs.getInt("transaction_id"));
                transaction.setAccountNo(rs.getInt("account_no"));
                transaction.setTransactionType(rs.getString("transaction_type"));
                transaction.setAmount(rs.getDouble("amount"));
                transaction.setTransactionDate(rs.getTimestamp("transaction_date"));
                transaction.setDescription(rs.getString("description"));

                transactions.add(transaction);
            }

        } catch (SQLException e)
        {
            System.err.println("Error getting transactions by account: " + e.getMessage());
        }

        return transactions;
    }

    @Override
    public List<Transaction> getTransactionsByDateRange(int accountNo, java.util.Date startDate, java.util.Date endDate) {
        List<Transaction> transactions = new ArrayList<>();
        String sql = "SELECT * FROM transactions WHERE account_no = ? AND transaction_date BETWEEN ? AND ? ORDER BY transaction_date DESC";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql))
        {

            ps.setInt(1, accountNo);
            ps.setDate(2, new java.sql.Date(startDate.getTime()));
            ps.setDate(3, new java.sql.Date(endDate.getTime()));

            ResultSet rs = ps.executeQuery();

            while (rs.next())
            {
                Transaction transaction = new Transaction();
                transaction.setTransactionId(rs.getInt("transaction_id"));
                transaction.setAccountNo(rs.getInt("account_no"));
                transaction.setTransactionType(rs.getString("transaction_type"));
                transaction.setAmount(rs.getDouble("amount"));
                transaction.setTransactionDate(rs.getTimestamp("transaction_date"));
                transaction.setDescription(rs.getString("description"));

                transactions.add(transaction);
            }

        } catch (SQLException e)
        {
            System.err.println("Error getting transactions by date range: " + e.getMessage());
        }

        return transactions;
    }

    @Override
    public List<Transaction> getAllTransactions()
    {
        List<Transaction> transactions = new ArrayList<>();
        String sql = "SELECT * FROM transactions ORDER BY transaction_date DESC";

        try (Connection connection = DatabaseConnection.getConnection();
             Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql))
        {

            while (rs.next())
            {
                Transaction transaction = new Transaction();
                transaction.setTransactionId(rs.getInt("transaction_id"));
                transaction.setAccountNo(rs.getInt("account_no"));
                transaction.setTransactionType(rs.getString("transaction_type"));
                transaction.setAmount(rs.getDouble("amount"));
                transaction.setTransactionDate(rs.getTimestamp("transaction_date"));
                transaction.setDescription(rs.getString("description"));

                transactions.add(transaction);
            }

        } catch (SQLException e)
        {
            System.err.println("Error getting all transactions: " + e.getMessage());
        }
        return transactions;
    }

    @Override
    public double getTotalDeposits(int accountNo)
    {
        String sql = "SELECT COALESCE(SUM(amount), 0) as total_deposits FROM transactions WHERE account_no = ? AND transaction_type = 'DEPOSIT'";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql))
        {

            ps.setInt(1, accountNo);
            ResultSet rs = ps.executeQuery();

            if (rs.next())
            {
                return rs.getDouble("total_deposits");
            }

        } catch (SQLException e)
        {
            System.err.println("Error getting total deposits: " + e.getMessage());
        }

        return 0;
    }

    @Override
    public double getTotalWithdrawals(int accountNo)
    {
        String sql = "SELECT COALESCE(SUM(amount), 0) as total_withdrawals FROM transactions WHERE account_no = ? AND transaction_type = 'WITHDRAWAL'";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, accountNo);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getDouble("total_withdrawals");
            }

        } catch (SQLException e)
        {
            System.err.println("Error getting total withdrawals: " + e.getMessage());
        }

        return 0;
    }
}