package DAO.impl;

import DAO.CustomerDAO;
import Model.Customer;
import util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

  public class CustomerDAOimpl implements CustomerDAO
  {

    @Override
    public boolean addcustomer(Customer customer)
    {
        String sql = "INSERT INTO customers (name, email, phone, address) VALUES (?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql))
        {
            ps.setString(1, customer.getName());
            ps.setString(2, customer.getEmail());
            ps.setString(3, customer.getPhone());
            ps.setString(4, customer.getAddress());

            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e)
        {
            System.err.println("Error adding customer: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }



      @Override
    public Customer getCustomerById(int customerId)
      {
        String sql = "SELECT * FROM customers WHERE customer_id = ?";
        Customer customer = null;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql))
        {

            ps.setInt(1, customerId);
            ResultSet rs = ps.executeQuery();

            if (rs.next())
            {
                customer = new Customer();
                customer.setCustomerId(rs.getInt("customer_id"));
                customer.setName(rs.getString("name"));
                customer.setEmail(rs.getString("email"));
                customer.setPhone(rs.getString("phone"));
                customer.setAddress(rs.getString("address"));
                customer.setCreatedDate(rs.getDate("created_date"));
            }

        } catch (SQLException e)
        {
            System.err.println("Error getting customer: " + e.getMessage());
        }

        return customer;
    }

    @Override
    public Customer getCustomerByEmail(String email)
    {
        String sql = "SELECT * FROM customers WHERE email = ?";
        Customer customer = null;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql))
        {

            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();

            if (rs.next())
            {
                customer = new Customer();
                customer.setCustomerId(rs.getInt("customer_id"));
                customer.setName(rs.getString("name"));
                customer.setEmail(rs.getString("email"));
                customer.setPhone(rs.getString("phone"));
                customer.setAddress(rs.getString("address"));
                customer.setCreatedDate(rs.getDate("created_date"));
            }

        } catch (SQLException e)
        {
            System.err.println("Error getting customer by email: " + e.getMessage());
        }

        return customer;
    }

    @Override
    public List<Customer> getAllCustomers()
    {
        List<Customer> customers = new ArrayList<>();
        String sql = "SELECT * FROM customers ORDER BY customer_id";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql))
        {

            while (rs.next())
            {
                Customer customer = new Customer();
                customer.setCustomerId(rs.getInt("customer_id"));
                customer.setName(rs.getString("name"));
                customer.setEmail(rs.getString("email"));
                customer.setPhone(rs.getString("phone"));
                customer.setAddress(rs.getString("address"));
                customer.setCreatedDate(rs.getDate("created_date"));

                customers.add(customer);
            }

        } catch (SQLException e)
        {
            System.err.println("Error getting all customers: " + e.getMessage());
        }

        return customers;
    }

    @Override
    public boolean updateCustomer(Customer customer)
    {
        String sql = "UPDATE customers SET name = ?, phone = ?, address = ? WHERE customer_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql))
        {

            ps.setString(1, customer.getName());
            ps.setString(2, customer.getPhone());
            ps.setString(3, customer.getAddress());
            ps.setInt(4, customer.getCustomerId());

            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e)
        {
            System.err.println("Error updating customer: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean deleteCustomer(int customerId)
    {
        String sql = "DELETE FROM customers WHERE customer_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql))
        {

            ps.setInt(1, customerId);
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e)
        {
            System.err.println("Error deleting customer: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean customerExists(int customerId)
    {
        String sql = "SELECT * FROM customers WHERE customer_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql))
        {

            ps.setInt(1, customerId);
            ResultSet rs = ps.executeQuery();
            return rs.next();

        } catch (SQLException e)
        {
            System.err.println("Error checking customer existence: " + e.getMessage());
            return false;
        }
    }
}