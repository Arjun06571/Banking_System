package DAO.impl;

import DAO.AccountDAO;
import Model.Account;
import util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;


  public class AccountDAOimpl implements AccountDAO
  {
      @Override
      public boolean createAccount(Account account)
      {
          String sql =" insert into accounts (customer_id , account_type , balance) values (? , ? , ? )";

          try (Connection connectionection = DatabaseConnection.getConnection();
               PreparedStatement ps= connectionection.prepareStatement(sql))
          {
              ps.setInt(1,account.getCustomerId());
              ps.setString(2,account.getAccountType());
              ps.setDouble(3,account.getBalance());


              int rowsAffected = ps.executeUpdate();
              return rowsAffected > 0;
          }
          catch (SQLException e)
          {
              System.out.print(" Error creating account :- "+ e.getMessage());
              return false;
          }
      }



      @Override
      public Account getAccountByNumber(int accountNo)
      {
           String sql =" select * from accounts where account_no = ?";
           Account account = null;

           try (Connection connectionection = DatabaseConnection.getConnection();
           PreparedStatement ps = connectionection.prepareStatement(sql))
           {
               ps.setInt(1,accountNo);
               ResultSet rs = ps.executeQuery();

               if(rs.next())
               {
                   account = new Account();
                   account.setAccountNo(rs.getInt("account_no"));
                   account.setCustomerId(rs.getInt("customer_id"));
                   account.setAccountType(rs.getString("account_type"));
                   account.setBalance(rs.getDouble("balance"));
                   account.setCreatedDate(rs.getDate("created_date"));
                   account.setStatus(rs.getString("status"));
               }

           } catch (SQLException e)
           {
               System.err.println("Error getting account: " + e.getMessage());
           }
          return account;
      }



      @Override
      public List<Account> getAccountsByCustomerId(int customerId)
      {
          List<Account> accounts = new ArrayList<>();
          String sql = "SELECT * FROM accounts WHERE customer_id = ? ORDER BY account_no";

          try (Connection connection = DatabaseConnection.getConnection();
               PreparedStatement pstmt = connection.prepareStatement(sql))
          {

              pstmt.setInt(1, customerId);
              ResultSet rs = pstmt.executeQuery();

              while (rs.next()) {
                  Account account = new Account();
                  account.setAccountNo(rs.getInt("account_no"));
                  account.setCustomerId(rs.getInt("customer_id"));
                  account.setAccountType(rs.getString("account_type"));
                  account.setBalance(rs.getDouble("balance"));
                  account.setCreatedDate(rs.getDate("created_date"));
                  account.setStatus(rs.getString("status"));

                  accounts.add(account);
              }

          } catch (SQLException e)
          {
              System.err.println("Error getting customer accounts: " + e.getMessage());
          }

          return accounts;
      }



      @Override
      public List<Account> getAllAccounts()
      {
          List<Account> accounts = new ArrayList<>();
          String sql = "SELECT * FROM accounts ORDER BY account_no";

          try (Connection connection = DatabaseConnection.getConnection();
               Statement stmt = connection.createStatement();
               ResultSet rs = stmt.executeQuery(sql))
          {

              while (rs.next())
              {
                  Account account = new Account();
                  account.setAccountNo(rs.getInt("account_no"));
                  account.setCustomerId(rs.getInt("customer_id"));
                  account.setAccountType(rs.getString("account_type"));
                  account.setBalance(rs.getDouble("balance"));
                  account.setCreatedDate(rs.getDate("created_date"));
                  account.setStatus(rs.getString("status"));

                  accounts.add(account);
              }

          } catch (SQLException e)
          {
              System.err.println("Error getting all accounts: " + e.getMessage());
          }

          return accounts;
      }



      @Override
      public double getAccountBalance(int accountNo)
      {
          String sql = "SELECT balance FROM accounts WHERE account_no = ?";

          try (Connection connection = DatabaseConnection.getConnection();
               PreparedStatement pstmt = connection.prepareStatement(sql))
          {

              pstmt.setInt(1, accountNo);
              ResultSet rs = pstmt.executeQuery();

              if (rs.next())
              {
                  return rs.getDouble("balance");
              }

          } catch (SQLException e)
          {
              System.err.println("Error getting account balance: " + e.getMessage());
          }

          return -1; // Return -1 to indicate error
      }



      @Override
      public boolean updateAccountBalance(int accountNo, double newBalance)
      {
          String sql = "UPDATE accounts SET balance = ? WHERE account_no = ?";

          try (Connection connection = DatabaseConnection.getConnection();
               PreparedStatement pstmt = connection.prepareStatement(sql))
          {

              pstmt.setDouble(1, newBalance);
              pstmt.setInt(2, accountNo);

              int rowsAffected = pstmt.executeUpdate();
              return rowsAffected > 0;

          } catch (SQLException e)
          {
              System.err.println("Error updating account balance: " + e.getMessage());
              return false;
          }
      }



      @Override
      public boolean updateAccountStatus(int accountNo, String status)
      {
          String sql = "UPDATE accounts SET status = ? WHERE account_no = ?";

          try (Connection connection = DatabaseConnection.getConnection();
               PreparedStatement pstmt = connection.prepareStatement(sql))
          {

              pstmt.setString(1, status);
              pstmt.setInt(2, accountNo);

              int rowsAffected = pstmt.executeUpdate();
              return rowsAffected > 0;

          } catch (SQLException e)
          {
              System.err.println("Error updating account status: " + e.getMessage());
              return false;
          }
      }



      @Override
      public boolean closeAccount(int accountNo)
      {
          return updateAccountStatus(accountNo, "CLOSED");
      }


      @Override
      public boolean accountExists(int accountNo)
      {
          String sql = "SELECT 1 FROM accounts WHERE account_no = ?";

          try (Connection connection = DatabaseConnection.getConnection();
               PreparedStatement pstmt = connection.prepareStatement(sql))
          {

              pstmt.setInt(1, accountNo);
              ResultSet rs = pstmt.executeQuery();
              return rs.next();

          } catch (SQLException e)
          {
              System.err.println("Error checking account existence: " + e.getMessage());
              return false;
          }
      }


      @Override
      public boolean isAccountActive(int accountNo)
      {
          String sql = "SELECT status FROM accounts WHERE account_no = ?";

          try (Connection connection = DatabaseConnection.getConnection();
               PreparedStatement pstmt = connection.prepareStatement(sql))
          {

              pstmt.setInt(1, accountNo);
              ResultSet rs = pstmt.executeQuery();

              if (rs.next())
              {
                  return "ACTIVE".equalsIgnoreCase(rs.getString("status"));
              }

          } catch (SQLException e)
          {
              System.err.println("Error checking account status: " + e.getMessage());
          }

          return false;
      }
  }
