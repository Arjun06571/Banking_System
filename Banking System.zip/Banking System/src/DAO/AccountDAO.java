package DAO;

import Model.Account;
import java.util.List;

public interface AccountDAO
{

    // Create
    boolean createAccount(Account account);

    // Read
    Account getAccountByNumber(int accountNo);
    List<Account> getAccountsByCustomerId(int customerId);
    List<Account> getAllAccounts();
    double getAccountBalance(int accountNo);

    // Update
    boolean updateAccountBalance(int accountNo, double newBalance);
    boolean updateAccountStatus(int accountNo, String status);

    // Delete
    boolean closeAccount(int accountNo);

    // Validation
    boolean accountExists(int accountNo);
    boolean isAccountActive(int accountNo);
}