package DAO;

import model.Transaction;
import java.util.List;


public interface TransactionDAO
{
    // Create
    boolean addTransaction(Transaction transaction);

    // Read
    Transaction getTransactionById(int transactionId);
    List<Transaction> getTransactionsByAccount(int accountNo);
    List<Transaction> getTransactionsByDateRange(int accountNo, java.util.Date startDate, java.util.Date endDate);
    List<Transaction> getAllTransactions();

    // Reports
    double getTotalDeposits(int accountNo);
    double getTotalWithdrawals(int accountNo);
}