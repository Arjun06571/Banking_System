package main;

import Service.CustomerService;
import Service.AccountService;
import Model.Customer;
import Model.Account;
import model.Transaction;

import java.util.List;
import java.util.Scanner;
import java.text.SimpleDateFormat;

public class BankApplication
{
    private static CustomerService customerService = new  CustomerService();
    private static AccountService accountService = new AccountService();
    private static Scanner scanner = new Scanner(System.in);
    private static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    public static void main(String[] args)
    {
        System.out.println("🚀 Welcome to Bank Management System!");
        System.out.println("=====================================");

        showMainMenu();
    }

    private static void showMainMenu()
    {
        while (true)
        {
            System.out.println("\n📋 MAIN MENU");
            System.out.println("1. Customer Management");
            System.out.println("2. Account Management");
            System.out.println("3. Transactions");
            System.out.println("4. Reports");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");

            int choice = getIntInput();

            switch (choice)
            {
                case 1:
                    showCustomerMenu();
                    break;
                case 2:
                    showAccountMenu();
                    break;
                case 3:
                    showTransactionMenu();
                    break;
                case 4:
                    showReportsMenu();
                    break;
                case 5:
                    System.out.println("Thank you for using Bank Management System! 👋");
                    return;
                default:
                    System.out.println("Invalid option! Please try again.");
            }
        }
    }

    private static void showCustomerMenu()
    {
        while (true)
        {
            System.out.println("\n👥 CUSTOMER MANAGEMENT");
            System.out.println("1. Register New Customer");
            System.out.println("2. View All Customers");
            System.out.println("3. Search Customer by ID");
            System.out.println("4. Update Customer");
            System.out.println("5. Delete Customer");
            System.out.println("6. Back to Main Menu");
            System.out.print("Choose an option: ");

            int choice = getIntInput();

            switch (choice)
            {
                case 1:
                    registerCustomer();
                    break;
                case 2:
                    viewAllCustomers();
                    break;
                case 3:
                    searchCustomerById();
                    break;
                case 4:
                    updateCustomer();
                    break;
                case 5:
                    deleteCustomer();
                    break;
                case 6:
                    return;
                default:
                    System.out.println("Invalid option! Please try again.");
            }
        }
    }

    private static void showAccountMenu()
    {
        while (true)
        {
            System.out.println("\n💰 ACCOUNT MANAGEMENT");
            System.out.println("1. Create New Account");
            System.out.println("2. View Account Details");
            System.out.println("3. View Customer Accounts");
            System.out.println("4. View All Accounts");
            System.out.println("5. Close Account");
            System.out.println("6. Check Balance");
            System.out.println("7. Back to Main Menu");
            System.out.print("Choose an option: ");

            int choice = getIntInput();

            switch (choice)
            {
                case 1:
                    createAccount();
                    break;
                case 2:
                    viewAccountDetails();
                    break;
                case 3:
                    viewCustomerAccounts();
                    break;
                case 4:
                    viewAllAccounts();
                    break;
                case 5:
                    closeAccount();
                    break;
                case 6:
                    checkBalance();
                    break;
                case 7:
                    return;
                default:
                    System.out.println("Invalid option! Please try again.");
            }
        }
    }

    private static void showTransactionMenu()
    {
        while (true)
        {
            System.out.println("\n💳 TRANSACTIONS");
            System.out.println("1. Deposit");
            System.out.println("2. Withdraw");
            System.out.println("3. Transfer Funds");
            System.out.println("4. View Transaction History");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");

            int choice = getIntInput();

            switch (choice)
            {
                case 1:
                    deposit();
                    break;
                case 2:
                    withdraw();
                    break;
                case 3:
                    transfer();
                    break;
                case 4:
                    viewTransactionHistory();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option! Please try again.");
            }
        }
    }

    private static void showReportsMenu()
    {
        while (true)
        {
            System.out.println("\n📊 REPORTS");
            System.out.println("1. View All Customers Report");
            System.out.println("2. View All Accounts Report");
            System.out.println("3. View All Transactions");
            System.out.println("4. Back to Main Menu");
            System.out.print("Choose an option: ");

            int choice = getIntInput();

            switch (choice)
            {
                case 1:
                    viewAllCustomersReport();
                    break;
                case 2:
                    viewAllAccountsReport();
                    break;
                case 3:
                    viewAllTransactions();
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid option! Please try again.");
            }
        }
    }

    // Customer Management Methods
    private static void registerCustomer()
    {
        System.out.println("\n📝 Register New Customer");

        System.out.print("Enter Name: ");
        String name = scanner.nextLine();

        System.out.print("Enter Email: ");
        String email = scanner.nextLine();

        System.out.print("Enter Phone: ");
        String phone = scanner.nextLine();

        System.out.print("Enter Address: ");
        String address = scanner.nextLine();

        customerService.registerCustomer(name, email, phone, address);
    }

    private static void viewAllCustomers()
    {
        System.out.println("\n👥 All Customers");
        List<Customer> customers = customerService.getAllCustomers();

        if (customers.isEmpty())
        {
            System.out.println("No customers found!");
            return;
        }

        System.out.println("-----------------------------------------------------------------");
        System.out.printf("%-12s %-20s %-25s %-15s%n",
                "Customer ID", "Name", "Email", "Phone");
        System.out.println("-----------------------------------------------------------------");

        for (Customer customer : customers)
        {
            System.out.printf("%-12d %-20s %-25s %-15s%n",
                    customer.getCustomerId(),
                    customer.getName(),
                    customer.getEmail(),
                    customer.getPhone());
        }
        System.out.println("-----------------------------------------------------------------");
    }

    private static void searchCustomerById()
    {
        System.out.print("Enter Customer ID: ");
        int customerId = getIntInput();

        Customer customer = customerService.getCustomer(customerId);
        if (customer != null)
        {
            System.out.println("\n✅ Customer Found:");
            System.out.println("ID: " + customer.getCustomerId());
            System.out.println("Name: " + customer.getName());
            System.out.println("Email: " + customer.getEmail());
            System.out.println("Phone: " + customer.getPhone());
            System.out.println("Address: " + customer.getAddress());
            System.out.println("Registered: " + customer.getCreatedDate());
        }
    }

    private static void updateCustomer()
    {
        System.out.print("Enter Customer ID to update: ");
        int customerId = getIntInput();

        Customer customer = customerService.getCustomer(customerId);
        if (customer == null)
        {
            return;
        }

        System.out.print("Enter New Name (" + customer.getName() + "): ");
        String name = scanner.nextLine();
        if (name.trim().isEmpty()) name = customer.getName();

        System.out.print("Enter New Phone (" + customer.getPhone() + "): ");
        String phone = scanner.nextLine();
        if (phone.trim().isEmpty()) phone = customer.getPhone();

        System.out.print("Enter New Address (" + customer.getAddress() + "): ");
        String address = scanner.nextLine();
        if (address.trim().isEmpty()) address = customer.getAddress();

        customerService.updateCustomer(customerId, name, phone, address);
    }

    private static void deleteCustomer()
    {
        System.out.print("Enter Customer ID to delete: ");
        int customerId = getIntInput();

        // Check if customer has accounts
        List<Account> accounts = accountService.getCustomerAccounts(customerId);
        if (!accounts.isEmpty())
        {
            System.out.println("❌ Cannot delete customer! Customer has active accounts.");
            System.out.println("Please close all accounts first.");
            return;
        }

        System.out.print("Are you sure you want to delete customer " + customerId + "? (yes/no): ");
        String confirmation = scanner.nextLine();

        if (confirmation.equalsIgnoreCase("yes"))
        {
            customerService.deleteCustomer(customerId);
        } else
        {
            System.out.println("Deletion cancelled.");
        }
    }

    // Account Management Methods
    private static void createAccount()
    {
        System.out.println("\n💰 Create New Account");

        System.out.print("Enter Customer ID: ");
        int customerId = getIntInput();

        // Verify customer exists
        Customer customer = customerService.getCustomer(customerId);
        if (customer == null)
        {
            System.out.println("❌ Customer not found! Please register customer first.");
            return;
        }

        System.out.print("Enter Account Type (SAVINGS/CURRENT): ");
        String accountType = scanner.nextLine().toUpperCase();

        System.out.print("Enter Initial Deposit: ");
        double initialDeposit = getDoubleInput();

        accountService.createAccount(customerId, accountType, initialDeposit);
    }

    private static void viewAccountDetails()
    {
        System.out.print("Enter Account Number: ");
        int accountNo = getIntInput();

        Account account = accountService.getAccount(accountNo);
        if (account != null)
        {
            Customer customer = customerService.getCustomer(account.getCustomerId());
            System.out.println("\n✅ Account Details:");
            System.out.println("Account Number: " + account.getAccountNo());
            System.out.println("Customer: " + (customer != null ? customer.getName() : "N/A"));
            System.out.println("Account Type: " + account.getAccountType());
            System.out.println("Balance: $" + account.getBalance());
            System.out.println("Status: " + account.getStatus());
            System.out.println("Created: " + account.getCreatedDate());
        }
    }

    private static void viewCustomerAccounts()
    {
        System.out.print("Enter Customer ID: ");
        int customerId = getIntInput();

        List<Account> accounts = accountService.getCustomerAccounts(customerId);

        if (accounts.isEmpty())
        {
            System.out.println("No accounts found for this customer!");
            return;
        }

        System.out.println("\n💰 Customer Accounts:");
        System.out.println("------------------------------------------------------------");
        System.out.printf("%-15s %-12s %-12s %-10s%n",
                "Account No", "Type", "Balance", "Status");
        System.out.println("------------------------------------------------------------");

        for (Account account : accounts)
        {
            System.out.printf("%-15d %-12s $%-11.2f %-10s%n",
                    account.getAccountNo(),
                    account.getAccountType(),
                    account.getBalance(),
                    account.getStatus());
        }
        System.out.println("------------------------------------------------------------");
    }

    private static void viewAllAccounts()
    {
        System.out.println("\n💰 All Accounts");
        List<Account> accounts = accountService.getAllAccounts();

        if (accounts.isEmpty())
        {
            System.out.println("No accounts found!");
            return;
        }

        System.out.println("-----------------------------------------------------------------------------");
        System.out.printf("%-12s %-12s %-20s %-12s %-12s %-10s%n",
                "Account No", "Customer ID", "Customer Name", "Type", "Balance", "Status");
        System.out.println("-----------------------------------------------------------------------------");

        for (Account account : accounts)
        {
            Customer customer = customerService.getCustomer(account.getCustomerId());
            String customerName = customer != null ? customer.getName() : "N/A";

            System.out.printf("%-12d %-12d %-20s %-12s $%-11.2f %-10s%n",
                    account.getAccountNo(),
                    account.getCustomerId(),
                    customerName,
                    account.getAccountType(),
                    account.getBalance(),
                    account.getStatus());
        }
        System.out.println("-----------------------------------------------------------------------------");
    }

    private static void closeAccount()
    {
        System.out.print("Enter Account Number to close: ");
        int accountNo = getIntInput();

        System.out.print("Are you sure you want to close account " + accountNo + "? (yes/no): ");
        String confirmation = scanner.nextLine();

        if (confirmation.equalsIgnoreCase("yes"))
        {
            accountService.closeAccount(accountNo);
        } else
        {
            System.out.println("Account closure cancelled.");
        }
    }

    private static void checkBalance() {
        System.out.print("Enter Account Number: ");
        int accountNo = getIntInput();

        accountService.getBalance(accountNo);
    }

    // Transaction Methods
    private static void deposit()
    {
        System.out.println("\n💵 Deposit Money");

        System.out.print("Enter Account Number: ");
        int accountNo = getIntInput();

        System.out.print("Enter Amount to Deposit: ");
        double amount = getDoubleInput();

        accountService.deposit(accountNo, amount);
    }

    private static void withdraw()
    {
        System.out.println("\n💸 Withdraw Money");

        System.out.print("Enter Account Number: ");
        int accountNo = getIntInput();

        System.out.print("Enter Amount to Withdraw: ");
        double amount = getDoubleInput();

        accountService.withdraw(accountNo, amount);
    }

    private static void transfer()
    {
        System.out.println("\n🔄 Transfer Funds");

        System.out.print("Enter From Account Number: ");
        int fromAccount = getIntInput();

        System.out.print("Enter To Account Number: ");
        int toAccount = getIntInput();

        System.out.print("Enter Amount to Transfer: ");
        double amount = getDoubleInput();

        accountService.transfer(fromAccount, toAccount, amount);
    }

    private static void viewTransactionHistory()
    {
        System.out.print("Enter Account Number: ");
        int accountNo = getIntInput();

        List<Transaction> transactions = accountService.getTransactionHistory(accountNo);

        if (transactions == null || transactions.isEmpty())
        {
            System.out.println("No transactions found for this account!");
            return;
        }

        System.out.println("\n📋 Transaction History for Account: " + accountNo);
        System.out.println("--------------------------------------------------------------------------------");
        System.out.printf("%-15s %-15s %-12s %-10s %-20s%n",
                "Transaction ID", "Type", "Amount", "Date", "Description");
        System.out.println("--------------------------------------------------------------------------------");

        for (Transaction transaction : transactions)
        {
            System.out.printf("%-15d %-15s $%-11.2f %-10s %-20s%n",
                    transaction.getTransactionId(),
                    transaction.getTransactionType(),
                    transaction.getAmount(),
                    dateFormat.format(transaction.getTransactionDate()),
                    transaction.getDescription());
        }
        System.out.println("--------------------------------------------------------------------------------");
    }

    // Report Methods
    private static void viewAllCustomersReport()
    {
        viewAllCustomers(); // Reuse existing method
    }

    private static void viewAllAccountsReport()
    {
        viewAllAccounts(); // Reuse existing method
    }

    private static void viewAllTransactions()
    {
        System.out.println("\n📊 All Transactions");
        // This would require adding a method to TransactionService to get all transactions
        System.out.println("Feature coming soon!");
    }

    // Utility Methods
    private static int getIntInput()
    {
        while (true)
        {
            try
            {
                return Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e)
            {
                System.out.print("Invalid input! Please enter a valid number: ");
            }
        }
    }

    private static double getDoubleInput()
    {
        while (true)
        {
            try
            {
                return Double.parseDouble(scanner.nextLine());
            } catch (NumberFormatException e)
            {
                System.out.print("Invalid input! Please enter a valid amount: ");
            }
        }
    }
}